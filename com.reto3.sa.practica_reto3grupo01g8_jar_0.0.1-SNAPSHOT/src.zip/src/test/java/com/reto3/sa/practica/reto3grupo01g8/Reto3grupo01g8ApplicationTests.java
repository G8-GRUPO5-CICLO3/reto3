package com.reto3.sa.practica.reto3grupo01g8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3grupo01g8ApplicationTests {

	@Test
	void contextLoads() {
	}

}

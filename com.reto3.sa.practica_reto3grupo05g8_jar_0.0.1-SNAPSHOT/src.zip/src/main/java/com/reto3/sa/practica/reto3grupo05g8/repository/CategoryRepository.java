
package com.reto3.sa.practica.reto3grupo05g8.repository;
import com.reto3.sa.practica.reto3grupo05g8.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio
 * @author Har
 */
//@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

}

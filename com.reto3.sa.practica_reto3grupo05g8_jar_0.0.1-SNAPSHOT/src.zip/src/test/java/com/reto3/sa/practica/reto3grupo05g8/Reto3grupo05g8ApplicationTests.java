package com.reto3.sa.practica.reto3grupo05g8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3grupo05g8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
